﻿HAR2JMX
Version 0.1.0.0
Date: 2025/01/22
==========================


Description: 
    HAR2JMX is a utility for taking an HTTP Archive (HAR) file as input and transforming 
    it into a Java Management Extensions (JMX) file for use in Apache JMeter. HAR2JMX can also
    convert the HAR file to a CSV file. HAR2JMX can take advantage of "transactional markers" 
    in the recorded HAR file and automatically groups sets of requests into a transaction with 
    JMeter. A sample HAR file is included with HAR2JMX which demonstrates the use of "transactional 
    markers".
    Currently, HAR2JMX is only a command-line only utility.
    The tool is made available in the .NET 8.0 portable runtime for Windows (win-x64), Linux (linux-x64), macOS (osx-x64).


System Requirements:
    A 64bit Operating System that is supported by .NET 8.0
       .NET on Windows dependencies (https://docs.microsoft.com/en-us/dotnet/core/install/windows?tabs=net50#dependencies)
       .NET on Linux dependencies (https://docs.microsoft.com/en-us/dotnet/core/install/linux)
       .NET on macOS dependencies (https://docs.microsoft.com/en-us/dotnet/core/install/macos#dependencies)
    RAM: 4GB



-------------------------------
* CHANGELOG


Build 0.1.0.0 (Prerelease)
1. Added the ability to convert the HAR file to an output of type CSV (comma separated values)
   Information on the HAR specification Timing properties can be found here: http://www.softwareishard.com/blog/har-12-spec/#timings
   The CSV output includes the Timing property values as columns for each request
2. Fixed an issue with JMX conversion where the Name in the HTTP Request element would be empty if the Path contained the value of "/server/rest/services"
3. JMX files created by HAR2JMX now list the JMeter version as 5.6.3 (this listing is mainly cosmetic)

Build 0.0.15.0 (Prerelease)
1. Moved HAR2JMX to .NET8
2. Added an option (-shm true) to add a "simplified" HTTP Header Manager element to the Test Plan, instead of an HTTP Header Manager to every request; the simplified element is not variablized and contains pre-canned values; this element is added directly under the Test Plan element
3. Added improved support to better handle an "inserted transaction marker" into the har file
4. Moved the "View Results Tree" element from Thread Group to be directly under the Test Plan
5. Added a Response Assertion element that fails any request with the word "error" in its response; by default, this element is not enabled
6. Added an option (-udv true) to add a dedicated User Defined Variables element to the Test Plan, instead of putting detected variables in the Test Plan element
7. Added a HTTP Request Defaults element to the Test Plan
8. Several useful static variables the both "User Defined Variables" sections (whichever is enabled); these variables (e.g., ${testPlanName}, ${requestConnectTimeout}, ${requestResponseTimeout}) are referenced and utilized in the HTTP Request Defaults element
9. Added an option (-ps true) to toggle the "Generate Parent Sample" option per transaction; default is true
10. In addition to osx-x64, binaries are built for osx-arm64

Build 0.0.14.2 (Prerelease)
1. Fixed an issue where the parser, when variablizing the ArcGIS components in the Test Plan, might skip the portal webadaptor inance name (e.g. "portal" in "/portal/home")
2. Fixed an issue where the parser, when variablizing the ArcGIS components in the Test Plan, would treat "portal/sharing" as the name of the portal webadaptor instance instead of just "portal"

Build 0.0.14.1 (Prerelease)
1. Removed a console print statement (for debugging) that would clutter the screen when the "-v true" option was passed in as a parameter

Build 0.0.14.0 (Prerelease)
1. Fixed an issue where the neither the instance nor service name were "variablized" in an HTTP Referer header element
2. Added a timestamp (local datetime) to the comments of the Test Plan listing when the jmx file was generated

Build 0.0.13.0 (Prerelease)
1. Set default JMeter Test Plan version to 5.4
2. Fixed an issue where the name of the ArcGIS Server service in the Request's Path field would not get parameterized
3. Optimized the name of the HTTP Sampler (e.g. Request) for ArcGIS Server services; everything before /rest/services is omitted
4. Fixed an issue where the name of the Transaction would start with an underscore ("_")
5. Corrected release year listing on DLLs and Exe for builds on Windows

Build 0.0.12.0 (Prerelease)
1. Fix an issue where HAR2JMX would crash if an HTTP request contained a key/value pair where the key was null but the value was populated
2. Added a boolean "-c" option (default is true) that appends a incrementing number at the end of each request name; this can assist with troubleshooting if there are many requests in the Test Plan

Build 0.0.11.5 (Prerelease)
1. Corrected an issue with the internal HAR library that had defined some of the numeric data types in the Timings class as int, all the objects were changed to float

Build 0.0.11.4 (Prerelease)
1. Previous builds of HAR2JMX contained an internal class model based on HAR files created from Fiddler v5.0.20194.41348 for .NET 4.6.1; however, using HAR files from Chrome (DevTools) Version 90.0.4430.93 appear to be more flexible

Build 0.0.11.3 (Prerelease)
1. Build version correction
2. Adjusted Copyright verbosity on generated files
3. Increased some error message verbosity when reading in a HAR file

Build 0.0.11.2 (Prerelease)
1. Updates to the Third_Party_Software_README.txt file

Build 0.0.11.1 (Prerelease)
1. Along with a portal runtime for Windows, portal runtimes for Linux and macOS are also included
2. Included a sample HAR for testing HAR2JMX and for seeing the advantage of using "transactional markers" when recording the HTTP workflow.
   A transactional marker is just a fictious request that begins with word: "https://transaction"; this is manually added after a list of valid requests.
   This fictious request typically results in an HTTP 500 error by the HTTP Debugging (such an error can be ignored).
   You can "name" your transactional marker by adding a hyphen and a string after the word transaction, for example: "https://transaction-InitialApplicationLoad".
   Note: not all HTTP Debugging tools allow you to manually add such a request to the list of valid requests.
3. Fixed an issue with POST parameters where some HAR files included an empty key/value set of ("text"/""); such key/value pairs are now ignored by the parser
4. Fixed an issue with POST parameters in the generated JMX file where the contents of the key was populated with the contents of the value

Build 0.0.11.0 (Prerelease)
1. Add -v option which creates variables in the generated JMX file for request components like server name, port, (arcgis) instance, (arcgis) service name, and (arcgis) token
2. Force URL Encoding of all GET request key/value pairs; this makes the internal logic simpler and the test playback behavior more consistent

Build 0.0.10.1 (Prerelease)
1. Fine tuned assembly 
2. .NET Core 5.0 single file availability of the executable
3. Optimized the size of the single file executable

Build 0.0.10.0 (Prerelease)
1. Initial release of rewrite
   Original was Har2Web (transformed a HAR file into a Visual Studio webtest)


